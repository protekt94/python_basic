# Цель задания
# Научиться работать с числами с плавающей точкой (int/float)

#Что нужно сделать:
#Зайдите в файлы с заданиями и выполните так чтобы вывод соотвествовал условиям.= # import task_1
import task_2
import task_3
import task_4
import task_5
import task_6
import task_7
import task_8
import task_9
import task10
